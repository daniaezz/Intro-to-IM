//class for the objects that block the user from moving forward
class Blocker {
  constructor(x, y, h, direction) {
    this.x = x;
    this.y = y;
    this.w = 20;
    this.h = h;
    this.dir = direction;
  }

  display() {
    this.x -= movex;
    this.newX = this.x - this.w;
    this.newY = this.y - this.h;
    fill(19, 49, 59);
    noStroke();
    rect(this.newX, this.newY, this.w, this.h);
  }
}
