//player class, used for collision checks and dictating user movment
class Chiken {
  constructor(x, y, r, ground) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.ground = ground;
    this.vy = 0;
    this.vx = 0;
    this.direction = "right";
    this.handler = { LEFTT: false, RIGHTT: false, UP: false }; //used along with keyCode to help make the movment smoother
  }

  //makes the user fall if there is no platform underneath
  gravity() {
    if (this.y + this.r >= this.ground) {
      this.vy = 0;
    } else {
      this.vy += 0.5;
      if (this.y + this.r + this.vy >= this.ground) {
        this.y = this.ground - this.r;
        this.vy = 0;
      }
    }
    for (let j = 0; j < platforms.length; j++) {
      if (
        this.y + this.r <= platforms[j].y &&
        this.x + this.r / 1.5 >= platforms[j].x &&
        this.x + this.r / 2.8 <= platforms[j].x + platforms[j].w
      ) {
        this.ground = platforms[j].y;
      }
    }
  }

  //makes the user stop if theres a blocker infront of them 
  block() {
    for (let i = 0; i < blockers.length; i++) {
      if (this.direction == "right") {
        if (
          this.x + this.r >= blockers[i].newX &&
          this.x + this.r <= blockers[i].x &&
          this.y + this.r <= blockers[i].y &&
          blockers[i].newY <= this.y + this.r
        ) {
          this.vx = 0;
          movex = 0;
        }
      } else if (this.direction == "left") {
        if (
          this.x <= blockers[i].x &&
          this.x >= blockers[i].newX &&
          this.y + this.r <= blockers[i].y &&
          blockers[i].newY < this.y + this.r
        ) {
          this.vx = 0;
          movex = 0;
        }
      }
    }
  }

  //defines the x and y velocity depending on different actions
  user() {
    if (this.handler.RIGHTT) {
      if (this.x > 720) {
        this.vx = 0;
        movex = 5;
      } else {
        this.vx = 5;
        movex = 0;
      }
      this.direction = "right";

      this.block();
      image(chikenRunF[cr], this.x, this.y, this.r, this.r);
    } else if (this.handler.LEFTT) {
      if (this.x <= 0 && platforms[1].x < 0) {
        movex = -5;
        this.vx = 0;
      } else if (this.x <= 0) {
        this.vx = 0;
      } else {
        this.vx = -5;
      }
      this.direction = "left";
      this.block();
      image(chikenRunB[cr], this.x, this.y, this.r, this.r);
    } else {
      this.vx = 0;
    }
    if (this.handler.UP && this.y + this.r >= this.ground) {
      this.vy = -10;
    }
  }

  //displays the correct image and movment depending on previous functions and inputs
  display() {
    this.gravity();
    this.user();
    this.x = this.x + this.vx;
    this.y = this.y + this.vy;
    if (this.direction == "right" && !this.handler.RIGHTT) {
      this.block();
      movex = 0;

      image(chikenIdleF[ci], this.x, this.y, this.r, this.r);
    } else if (this.direction == "left" && !this.handler.LEFTT) {
      this.block();
      movex = 0;

      image(chikenIdleB[ci], this.x, this.y, this.r, this.r);
    }
  }
}
