//class that contains all the set up required for the game, mainly used to help restart the game
class Game {
  platformSetup() {
    platforms.push(new Platform(0, 580, width, height - 600));
    platforms.push(new Platform(230, 480, 200, 30));
    platforms.push(new Platform(370 + 40, 380, 200, 30));
    platforms.push(new Platform(665, 330, 200, 30));
    platforms.push(new Platform(909, 420, 200, 30));
    platforms.push(new Platform(1090, 330, 400, 30));
    platforms.push(new Platform(1494, 490, 200, 30));
    platforms.push(new Platform(1734, 420, 280, 30));
    platforms.push(new Platform(2074, 330, 200, 30));
    platforms.push(new Platform(2274, 385, 340, 30));
    platforms.push(new Platform(2614 + 40, 310, 180, 30));
    platforms.push(new Platform(2614 + 40 + 180, 230, 180, 30));
    platforms.push(new Platform(2614 + 40 + 360, 370, 180, 30));
    platforms.push(new Platform(3414 - 20, 480, 150, 30));
    platforms.push(new Platform(3564 - 40, 380 + 10, 230, 30));
    platforms.push(new Platform(3800, 380, 180, 30));
    platforms.push(new Platform(4000, 490, 160, 30));
    platforms.push(new Platform(4180, 420, 160, 30));
    platforms.push(new Platform(4000, 340, 160, 30));
    platforms.push(new Platform(4180, 250, 160, 30));
    platforms.push(new Platform(4360, 200, 180, 30));
    platforms.push(new Platform(4610, 170, 180, 30));
    platforms.push(new Platform(4810, 90, 160, 30));
    platforms.push(new Platform(4810 + 140, 370, 250, 30));
  }

  blockerSetup() {
    blockers.push(new Blocker(250, 580, 100));
    blockers.push(new Blocker(390 + 40, 480, 100));
    blockers.push(new Blocker(530 + 40 + 40, 410, 100));
    blockers.push(new Blocker(1109, 450, 120));
    blockers.push(new Blocker(1490, 332, 200));
    blockers.push(new Blocker(2274, 500, 310 - 80));
    blockers.push(new Blocker(2614, 410, 100));
    blockers.push(new Blocker(2614 + 40 + 360 + 180, 180, 150));
    blockers.push(new Blocker(3194, 580, 210));
    blockers.push(new Blocker(2614 + 40 + 180, 310, 80));
    blockers.push(new Blocker(2614 + 40 + 360, 230, 80));
    blockers.push(new Blocker(3414, 580, 100));
    blockers.push(new Blocker(3564 - 20, 480, 80));
    blockers.push(new Blocker(3564 + 150, 200, 200));
    blockers.push(new Blocker(3800 + 180, 380, 380));
    blockers.push(new Blocker(4560, 500, 380));
    blockers.push(new Blocker(4810 + 160, 370, 350));
    blockers.push(new Blocker(4810 + 140 + 250, 580, 580));
  }

  spriteSetup() {
    for (let i = 0; i < 10; i++) {
      let tempImage = chikenBoiRunF.get(
        0,
        (i * chikenBoiRunF.height) / 10,
        chikenBoiRunF.width,
        chikenBoiRunF.height / 10
      );

      chikenRunF.push(tempImage);
    }

    for (let i = 0; i < 10; i++) {
      let tempImage = chikenBoiRunB.get(
        0,
        (i * chikenBoiRunB.height) / 10,
        chikenBoiRunB.width,
        chikenBoiRunB.height / 10
      );

      chikenRunB.push(tempImage);
    }

    for (let j = 0; j < 6; j++) {
      let tempImage = chikenBoiIdleF.get(
        0,
        (j * chikenBoiIdleF.height) / 6,
        chikenBoiIdleF.width,
        chikenBoiIdleF.height / 6
      );

      chikenIdleF.push(tempImage);
    }

    for (let j = 0; j < 6; j++) {
      let tempImage = chikenBoiIdleB.get(
        0,
        (j * chikenBoiIdleB.height) / 6,
        chikenBoiIdleB.width,
        chikenBoiIdleB.height / 6
      );

      chikenIdleB.push(tempImage);
    }

    for (let i = 0; i < 6; i++) {
      let tempImage = witchGalIdle.get(
        0,
        (i * witchGalIdle.height) / 6,
        witchGalIdle.width,
        witchGalIdle.height / 6
      );

      witchIdle.push(tempImage);
    }

    for (let j = 0; j < 6; j++) {
      let tempImage = ketKnightIdle.get(
        0,
        (j * (10 + ketKnightIdle.height)) / 6,
        ketKnightIdle.width,
        ketKnightIdle.height / 6
      );

      ketIdle.push(tempImage);
    }
  }
}
