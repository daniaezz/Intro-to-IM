// class for the cat, used to aid with the user collision and resetting its position on restart
class Ket {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  
  display(){
    this.x -= movex
    image(ketIdle[ki], this.x, this.y, ketIdle[ki].width*3, ketIdle[ki].height*3);

  }
}
