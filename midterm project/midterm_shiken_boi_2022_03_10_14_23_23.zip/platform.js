//class for the platforms that the player steps on
class Platform {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }

  display() {
    fill(100, 0, 30);
    this.x -= movex;
    image(platformImage, this.x, this.y, this.w, this.h);
  }
}
