let backgroundImage = [];
let chikenBoiRunF;
let chikenRunF = [];
let chikenBoiRunB;
let chikenRunB = [];
let chikenBoiIdleF;
let chikenBoiIdleB;
let chikenIdleF = [];
let chikenIdleB = [];
let witchGalIdle;
let witchIdle = [];
let ketKnightIdle;
let ketIdle = [];
let platformImage;
let font;
let cr = 0; //chicken run
let ci = 0; //chicken idle
let platforms = [];
let ground;
let chiken;
let platform;
let blockers = [];
let movex = 0;
let ki = 0; //ket idle
let ketto;
let moosic;
let screen = 0;
let game;

function preload() {
  moosic = loadSound("assets/moosic.mp3");
  platformImage = loadImage("assets/platform.png");
  chikenBoiRunF = loadImage("assets/chiken/runR.png");
  chikenBoiRunB = loadImage("assets/chiken/runL.png");
  chikenBoiIdleF = loadImage("assets/chiken/idle.png");
  chikenBoiIdleB = loadImage("assets/chiken/idleB.png");
  witchGalIdle = loadImage("assets/witch/idle.png");
  ketKnightIdle = loadImage("assets/ket/idle.png");
  font = loadFont("assets/font.ttf");
  for (let i = 1; i < 7; i++) {
    temp = "assets/background/" + i + ".png";
    backgroundImage.push(loadImage(temp));
  }
}

function setup() {
  createCanvas(1240, 720);
  game = new Game();
  game.spriteSetup();
  game.platformSetup();
  game.blockerSetup();
  ground = platforms[0];
  chiken = new Chiken(100, 100, 80, ground.y);
  ketto = new Ket(5075, 330);

  moosic.loop();
}

function draw() {
  for (let i = 0; i < backgroundImage.length; i++) {
    image(
      backgroundImage[i],
      0,
      0,
      backgroundImage[i].width * 2,
      backgroundImage[i].height * 2
    );
  }
  fill(255);
  textFont(font);
  textSize(15);
  
  //start screen
  if (screen == 0) {
    image(
      chikenIdleF[0],
      385,
      399,
      chikenIdleF[0].width * 2,
      chikenIdleF[0].height * 2
    );
    image(
      chikenIdleB[0],
      773,
      400,
      chikenIdleB[0].width * 2,
      chikenIdleB[0].height * 2
    );
    image(ketIdle[0], 550, 240, ketIdle[0].width * 6, ketIdle[0].height * 6);
    text("Shiken - Boi", width / 2 - 100, height / 2);
    text("CLICK TO START", width / 2 - 110, height / 2 + 100);
  } 
  
  //context screen
  else if (screen == 1) {
    image(chikenIdleB[ci], 940, 580 - 80, 80, 80);
    textSize(12);
    fill(0);
    text("huh, why do i suddenly have feathers", 750, 380);
    image(
      witchIdle[ci],
      150,
      480,
      witchIdle[ci].width * 2.35,
      witchIdle[ci].height * 2.35
    );
    text(
      "you turned into a chicken, i'll turn you back if you get me my cat",
      100,
      450
    );
    fill(255);
    text("CLICK TO CONTINUE", width / 2 - 110, 630);
  } 
  
  
  //maze screen
  else if (screen == 2) {
    for (let i = 0; i < blockers.length; i++) {
      blockers[i].display();
    }
    for (let i = 1; i < platforms.length; i++) {
      platforms[i].display();
    }

    ketto.display();
    chiken.display();

    //checks for collision with cat and resets the game if its won
    if (dist(chiken.x, chiken.y, ketto.x, ketto.y) < 70) {
      movex = 0;

      screen++;
      chiken = new Chiken(100, 100, 80, ground.y);
      platforms = [];
      blockers = [];
      game.platformSetup();
      game.blockerSetup();

      ketto = new Ket(5075, 330);
    }
  } 
  
  //winning screen
  else if (screen > 2) {
    textSize(20);
    text("YOU WON!!!", width / 2 - 100, height / 2);
    text("CLICK TO PLAY AGAIN", width / 2 - 180, 630);
  }
  
  //counter to iterate over sprites
  if (frameCount % 6 == 0) {
    ci++;
    ci = ci % 6;
    cr++;
    cr = cr % 6;
    ki++;
    ki = ki % 6;
  }
}

//changes the value of true and false for the chiken class
function keyPressed() {
  if (keyCode == LEFT_ARROW) {
    chiken.handler.LEFTT = true;
  } else if (keyCode == RIGHT_ARROW) {
    chiken.handler.RIGHTT = true;
  } else if (keyCode == UP_ARROW) {
    chiken.handler.UP = true;
  }
}

function keyReleased() {
  if (keyCode == LEFT_ARROW) {
    chiken.handler.LEFTT = false;
  } else if (keyCode == RIGHT_ARROW) {
    chiken.handler.RIGHTT = false;
  } else if (keyCode == UP_ARROW) {
    chiken.handler.UP = false;
  }
}

//changes screen 
function mousePressed() {
  if (screen < 2) {
    screen++;
  } else if (screen > 2) {
    screen = 0;
  }
}
